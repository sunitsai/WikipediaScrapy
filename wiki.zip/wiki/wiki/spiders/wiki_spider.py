import scrapy
from scrapy import Spider
from wiki.items import WikiItem

class wikiSpider(Spider):
    name = "wiki"
    start_urls = [
        'https://en.wikipedia.org/wiki/Python_(programming_language)'
    ]


    def parse(self, response):
        wikitable = response.xpath('//table[@class="wikitable"]//tr')
        del wikitable[0]

        for w in wikitable:
            item = WikiItem()
            item['type'] = w.xpath('.//td[1]/code/text()').get()
            item['mutibility'] = w.xpath('.//td[2]/text()').get()
            item['description'] = w.xpath('.//td[3]/a/text()').get()
            item['syntax'] = w.xpath('.//td[4]/code/span[@class="bp"]/text()').get()
            yield item


from scrapy.cmdline import execute
execute('scrapy crawl wiki'.split())